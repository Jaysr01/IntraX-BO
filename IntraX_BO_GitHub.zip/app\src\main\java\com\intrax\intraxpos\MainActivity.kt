package com.intrax.intraxpos

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val CAMERA_PERMISSION_CODE = 101
    private val WEB_URL = "http://192.168.1.99"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        checkCameraPermission()

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.mediaPlaybackRequiresUserGesture = false

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    webView.loadUrl("about:blank")
                    showServerErrorDialog()
                }
            }
        }

        webView.addJavascriptInterface(WebAppInterface(this), "androidPrint")
        webView.loadUrl(WEB_URL)
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
        }
    }

    private fun showServerErrorDialog() {
        AlertDialog.Builder(this)
            .setTitle("Verbindingsfout")
            .setMessage("Kan geen verbinding maken met de server (). Controleer je netwerk/WiFi en probeer opnieuw.")
            .setCancelable(false)
            .setPositiveButton("Opnieuw Proberen") { dialog, _ ->
                dialog.dismiss()
                webView.loadUrl(WEB_URL)
            }
            .setNegativeButton("Sluiten") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    inner class WebAppInterface(private val context: Context) {
        @JavascriptInterface
        fun printReceipt() {
            runOnUiThread {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val printAdapter = webView.createPrintDocumentAdapter("Kassabon")
                val jobName = getString(R.string.app_name) + " Bon"
                printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
            }
        }
    }
}